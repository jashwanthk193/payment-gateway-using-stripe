package com.example.stripepay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StripepayApplicationTests {

	@Test
	void contextLoads() {
	}

}
