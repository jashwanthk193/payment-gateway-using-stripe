package com.example.stripepay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StripepayApplication {

	public static void main(String[] args) {
		SpringApplication.run(StripepayApplication.class, args);
	}

}
